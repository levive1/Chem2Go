import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class VIBDetailWindowA(QWidget):
    def __init__(self, texmes, vib_id):
        super().__init__()

        self.texmes = texmes
        self.vib_id = vib_id

        self.setWindowTitle("Stofdetails")
        self.setFixedSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.back = QPushButton("< Terug", self)
        self.back.move(5, 155)
        self.back.setFixedSize(80, 30)
        self.back.setStyleSheet("font-size: 14px; font-weight: bold; background-color: lightgray;")
        self.back.clicked.connect(self.gaterug)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: black;")
        line.setFixedHeight(2)

        self.standaard = QLabel("", self)    
        self.standaard.move(150, 190)
        self.standaard.setStyleSheet("font-size: 24px; font-weight: bold; color: white; background-color: white; border: 2px solid black;")
        self.standaard.setFixedSize(400, 350)

        self.toevoegen = QLabel("", self)    
        self.toevoegen.move(170, 205)
        self.toevoegen.setStyleSheet("font-size: 20px; font-weight: bold; color: black; background-color: white;")
        self.toevoegen.setFixedSize(250, 25)

        DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
        connect = sqlite3.connect(DB_PATH)
        cursor = connect.cursor()
        cursor.execute("SELECT * FROM VIBoverzicht WHERE id=?", (self.vib_id,))
        result = cursor.fetchone()

        self.toevoegen.setText(f"{result[1]}")

        self.toe1 = QLabel("", self)
        self.toe1.setText(f"{result[2]}")
        self.toe1.move(170, 240)
        self.toe1.setStyleSheet("font-size: 18px; font-style: italic; color: black; background-color: white;")
        self.toe1.setFixedSize(300, 25)

        self.toe2 = QLabel("", self)
        self.toe2.move(170, 270)
        self.toe2.setStyleSheet("font-size: 18px; font-style: italic; color: black; background-color: white;")
        self.toe2.setFixedSize(300, 25)

        if result[3] == "Verlopen":
            self.toe2.setText("Deze VIB is verlopen.")
        else:
            self.toe2.setText(f"Verloopt op {result[3]}.")

        self.toe3 = QLabel("Ophaalbaar via:", self)
        self.toe3.move(170, 340)
        self.toe3.setStyleSheet("font-size: 18px; color: black; background-color: white;")
        self.toe3.setFixedSize(350, 25)

        self.toe4 = QLabel(f"{result[4]}", self)
        self.toe4.move(170, 370)
        self.toe4.setStyleSheet("font-size: 18px; color: black; background-color: white;")
        self.toe4.setFixedSize(350, 30)

        connect.close()

    def gaterug(self):
        from .vib_window_admin import VIBWindowA # type: ignore
        self.window2 = VIBWindowA(self.texmes)
        self.window2.show()
        self.close()
