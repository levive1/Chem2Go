import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox

class HomeWindow(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.setWindowTitle("InlogPagina")
        self.setFixedSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        self.texmes = texmes
        self.inlog = QLabel(f"Welkom {self.texmes}!", self)
        self.inlog.setFixedSize(250, 20)
        self.inlog.setVisible(True)
        self.inlog.move(230, 170)
        self.inlog.setStyleSheet("font-size: 20px; color: white; font-weight: bold;")

        self.info = QLabel("Als scheikundige gebruikt u een website van het \nBeatrix College, uw rechten zijn beperkt.", self)
        self.info.setFixedSize(400, 50)
        self.info.setVisible(True)
        self.info.move(160, 200)
        self.info.setStyleSheet("font-size: 16px; color: white;")

        self.VIBzien = QPushButton("VIBs \nbekijken", self)
        self.VIBzien.move(200, 280)
        self.VIBzien.setFixedSize(200, 160)
        self.VIBzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBzien.clicked.connect(self.gaverderVIB)

    def gaverderVIB(self):
        from .vib_window import VIBWindow # type: ignore
        self.window3 = VIBWindow(self.texmes)
        self.window3.show()
        self.close()
