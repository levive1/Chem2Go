import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class voorraadaanpassen(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.texmes = texmes

        self.setWindowTitle("VIB aanpassen pagina")
        self.setFixedSize(700, 600)  
        self.setStyleSheet("background-color: #4CAF50;")  

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.back = QPushButton("< Terug", self)
        self.back.move(5, 155)
        self.back.setFixedSize(80, 30)
        self.back.setStyleSheet("font-size: 14px; font-weight: bold; background-color: lightgray;")
        self.back.clicked.connect(self.gaterug)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: black;")
        line.setFixedHeight(2)

        self.standaard = QLabel("", self)    
        self.standaard.move(100, 190)
        self.standaard.setStyleSheet("font-size: 24px; font-weight: bold; color: white; background-color: white; border: 2px solid black;")
        self.standaard.setFixedSize(500, 350)

        self.toevoegen = QLabel("Voorraad toevoegen of aanpassen", self)    
        self.toevoegen.move(120, 205)
        self.toevoegen.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.toevoegen.setFixedSize(350, 25)

        self.vuln = QLabel("Stofnaam:", self)    
        self.vuln.move(135, 250)
        self.vuln.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.vuln.setFixedSize(150, 25)

        self.vulna = QLineEdit(self)  
        self.vulna.setPlaceholderText("Naam van de stof")
        self.vulna.move(330, 250)
        self.vulna.setStyleSheet("font-size: 19px; color: black; background-color: lightgray;")
        self.vulna.setFixedSize(250, 25)

        self.vulu = QLabel("Locatie:", self)    
        self.vulu.move(135, 295)
        self.vulu.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.vulu.setFixedSize(150, 25)

        self.vulua = QLineEdit(self)  
        self.vulua.setPlaceholderText("Plek van de stof")
        self.vulua.move(330, 295)
        self.vulua.setStyleSheet("font-size: 19px; color: black; background-color: lightgray;")
        self.vulua.setFixedSize(250, 25)  

        self.vulvd = QLabel("Voorraad:", self)    
        self.vulvd.move(135, 340)
        self.vulvd.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.vulvd.setFixedSize(150, 25)

        self.vulvda = QLineEdit(self)  
        self.vulvda.setPlaceholderText("Hoeveelheid in g of ml")
        self.vulvda.move(330, 340)
        self.vulvda.setStyleSheet("font-size: 19px; color: black; background-color: lightgray;")
        self.vulvda.setFixedSize(250, 25)

        self.waar = QLabel("*Als de stofnaam wordt herkend, wordt de \nbestaande stof aangepast.", self)    
        self.waar.move(135, 390)
        self.waar.setStyleSheet("font-size: 16px; font-weight: italic; color: black; background-color: white;")
        self.waar.setFixedSize(350, 50)

        self.verstuur = QPushButton("Verstuur", self)
        self.verstuur.move(160, 450)
        self.verstuur.setFixedSize(100, 35)
        self.verstuur.setStyleSheet("font-size: 16px; font-weight: bold; background-color: lightgray;")
        self.verstuur.clicked.connect(self.verstuurdata)

        self.foutmelding = QLabel("", self)
        self.foutmelding.move(300, 450)
        self.foutmelding.setStyleSheet("font-size: 16px; font-weight: bold; color: black; background-color: white;")
        self.foutmelding.setFixedSize(200, 35)

    def gaterug(self):
        from .voorraad_window_admin import VoorraadWindowA # type: ignore
        self.window2 = VoorraadWindowA(self.texmes)
        self.window2.show()
        self.close()

    def verstuurdata(self):
        if self.vulna.text() == "" or self.vulua.text() == "" or self.vulvd.text() == "":
            self.foutmelding.setText("Vul alle velden in.")
            return
        else:
            DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
            connect = sqlite3.connect(DB_PATH)
            cursor = connect.cursor()

            cursor.execute("SELECT MAX(id) FROM stoffen")
            max_id = cursor.fetchone()[0]

            cursor.execute("SELECT stof FROM stoffen WHERE stof=?", (self.vulna.text(),))
            result = cursor.fetchone()

            if result:
                cursor.execute("""
                    UPDATE stoffen
                    SET locatie=?, voorraad=?
                    WHERE stof=?
                """, (self.vulua.text(), self.vulvda.text(), self.vulna.text()))
            else:
                cursor.execute("""
                    INSERT INTO stoffen (stof, locatie, voorraad)
                    VALUES (?, ?, ?)
                """, (self.vulna.text(), self.vulua.text(), self.vulvda.text()))

            cursor.execute("SELECT MAX(id) FROM stoffen")
            new_max_id = cursor.fetchone()[0]

            if new_max_id > max_id:
                messagebox.showinfo("Succes", "Nieuwe voorraad is toegevoegd.")
            elif new_max_id == max_id:
                messagebox.showinfo("Succes", "Bestaande voorraad is aangepast.")
            else: 
                messagebox.showinfo("Fout", "Er is een fout opgetreden, controleer of database.db is geïnstalleerd.")
            
            connect.commit()
            connect.close()
            from .home_window_admin import HomeWindowAdmin # type: ignore
            self.window2 = HomeWindowAdmin(self.texmes)
            self.window2.show()
            self.close()