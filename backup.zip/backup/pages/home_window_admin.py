import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox

class HomeWindowAdmin(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.setWindowTitle("WelkomPagina")
        self.setFixedSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        self.texmes = texmes
        self.inlog = QLabel(f"Welkom Admin {self.texmes}!", self)
        self.inlog.setFixedSize(250, 20)
        self.inlog.setVisible(True)
        self.inlog.move(230, 170)
        self.inlog.setStyleSheet("font-size: 19px; color: white; font-weight: bold;")

        self.info = QLabel("U bent ter beschikking van maximale rechten.", self)
        self.info.setFixedSize(400, 20)
        self.info.setVisible(True)
        self.info.move(165, 200)
        self.info.setStyleSheet("font-size: 16px; color: white;")

        self.VIBzien = QPushButton("VIBs", self)
        self.VIBzien.move(130, 240)
        self.VIBzien.setFixedSize(200, 160)
        self.VIBzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBzien.clicked.connect(self.gaverderVIB)

        self.voorraadzien = QPushButton("Voorraden", self)
        self.voorraadzien.move(340, 240)
        self.voorraadzien.setFixedSize(200, 160)
        self.voorraadzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.voorraadzien.clicked.connect(self.gaverdervoorraad)

        self.VIBverand = QPushButton("VIBs\nbewerken", self)
        self.VIBverand.move(130, 410)
        self.VIBverand.setFixedSize(200, 160)
        self.VIBverand.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBverand.clicked.connect(self.gaverderVIBaanpassen)

        self.voorraadverand = QPushButton("Voorraden\nbewerken", self)
        self.voorraadverand.move(340, 410)
        self.voorraadverand.setFixedSize(200, 160)
        self.voorraadverand.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.voorraadverand.clicked.connect(self.gaverdervoorraadaanpassen)

    def gaverdervoorraadaanpassen(self):
        from .voorraad_aanpassen import voorraadaanpassen # type: ignore
        self.window3 = voorraadaanpassen(self.texmes)
        self.window3.show()
        self.close()

    def gaverderVIBaanpassen(self):
        from .vib_aanpassen import vibaanpassen # type: ignore
        self.window3 = vibaanpassen(self.texmes)
        self.window3.show()
        self.close()

    def gaverdervoorraad(self):
        from .voorraad_window_admin import VoorraadWindowA # type: ignore
        self.window3 = VoorraadWindowA(self.texmes)
        self.window3.show()
        self.close()
    
    def gaverderVIB(self):
        from .vib_window_admin import VIBWindowA # type: ignore
        self.window3 = VIBWindowA(self.texmes)
        self.window3.show()
        self.close()
