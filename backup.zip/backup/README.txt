Voor gebruik is het vereist de ZIP-file uit te pakken
Om de applicatie in te laden runt u het programma start.py
Andere programmas zijn niet vereist en niet aangeraden te openen
