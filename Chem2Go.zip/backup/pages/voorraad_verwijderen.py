import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class voorraadverwijderen(QWidget):
    def __init__(self, texmes, oorsprong):
        super().__init__()

        self.texmes = texmes
        self.oorsprong = oorsprong

        self.setWindowTitle("Voorraad verwijderen pagina")
        self.resize(700, 600)
        self.setMinimumSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")  

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.back = QPushButton("< Terug", self)
        self.back.move(5, 155)
        self.back.setFixedSize(80, 30)
        self.back.setStyleSheet("QPushButton { font-size: 14px; font-weight: bold; background-color: lightgray; }" \
                                "QPushButton:hover { background-color: #F2F0ED; }")
        self.back.clicked.connect(self.gaterug)

        self.uitlog = QPushButton("Uitloggen", self)
        self.uitlog.move(600, 10)
        self.uitlog.setFixedSize(90, 30)
        self.uitlog.setStyleSheet(
            "QPushButton { font-size: 12px; font-weight: bold; "
            "background-color: lightgray; border: 2px solid black; padding: 2px; }"
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.uitlog.clicked.connect(self.uitloggen)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: black;")
        line.setFixedHeight(2)

        self.standaard = QLabel("", self)    
        self.standaard.move(100, 190)
        self.standaard.setStyleSheet("font-size: 24px; font-weight: bold; color: white; background-color: white; border: 2px solid black;")
        self.standaard.setFixedSize(500, 210)

        self.toevoegen = QLabel("Voorraad verwijderen", self)    
        self.toevoegen.move(120, 205)
        self.toevoegen.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.toevoegen.setFixedSize(250, 25)

        self.vuln = QLabel("Stofnaam:", self)    
        self.vuln.move(135, 250)
        self.vuln.setStyleSheet("font-size: 19px; color: black; background-color: white;")
        self.vuln.setFixedSize(150, 25)

        self.vulna = QLineEdit(self)  
        self.vulna.setPlaceholderText("Naam van de stof")
        self.vulna.move(330, 250)
        self.vulna.setStyleSheet("font-size: 19px; color: black; background-color: lightgray;")
        self.vulna.setFixedSize(250, 25)

        self.waar = QLabel("*Let op: verwijderingen zijn permanent!", self)    
        self.waar.move(135, 285)
        self.waar.setStyleSheet("font-size: 16px; font-weight: italic; color: black; background-color: white;")
        self.waar.setFixedSize(350, 50)

        self.verstuur = QPushButton("Verstuur", self)
        self.verstuur.move(160, 340)
        self.verstuur.setFixedSize(100, 35)
        self.verstuur.setStyleSheet("font-size: 16px; font-weight: bold; background-color: lightgray;")
        self.verstuur.clicked.connect(self.verstuurdata)

        self.foutmelding = QLabel("", self)
        self.foutmelding.move(300, 345)
        self.foutmelding.setStyleSheet("font-size: 16px; font-weight: bold; color: black; background-color: white;")
        self.foutmelding.setFixedSize(200, 35)


    def verstuurdata(self):
        if self.vulna.text() == "":
            self.foutmelding.setText("Vul de stofnaam in.")
            return
        else:
            DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
            connect = sqlite3.connect(DB_PATH)
            cursor = connect.cursor()

            cursor.execute("SELECT COUNT(id) FROM stoffen")
            max_id = cursor.fetchone()[0]

            cursor.execute("SELECT stof FROM stoffen WHERE stof=?", (self.vulna.text(),))
            result = cursor.fetchone()

            if result:
                cursor.execute("DELETE FROM stoffen WHERE stof=?", (self.vulna.text(),))

                cursor.execute("SELECT COUNT(id) FROM stoffen")
                new_max_id = cursor.fetchone()[0]

                if new_max_id < max_id:
                    messagebox.showinfo("Succes", "Bestaande voorraad is verwijderd.")
                else: 
                    messagebox.showinfo("Fout", "Er is een fout opgetreden, controleer of database.db is geïnstalleerd.")
            else: 
                messagebox.showinfo("Fout", "Er is geen voorraad gevonden met deze stofnaam.")
                connect.close()
                return

            connect.commit()
            connect.close()
            from .home_window_admin import HomeWindowAdmin  # type: ignore
            self.window2 = HomeWindowAdmin(self.texmes)
            self.window2.show()
            self.close()

    def gaterug(self):
        from .voorraad_aanpassen import voorraadaanpassen  # type: ignore
        self.window2 = voorraadaanpassen(self.texmes, self.oorsprong)
        self.window2.show()
        self.close()
    
    def uitloggen(self):
        from login_window import LoginWindow # type: ignore
        self.window1 = LoginWindow()
        self.window1.show()
        self.close()