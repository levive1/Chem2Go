import difflib
import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path
from difflib import get_close_matches

class VoorraadWindowA(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.texmes = texmes

        self.setWindowTitle("Voorraad pagina")
        self.resize(700, 600)
        self.setMinimumSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")  

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.uitlog = QPushButton("Uitloggen", self)
        self.uitlog.move(600, 10)
        self.uitlog.setFixedSize(90, 30)
        self.uitlog.setStyleSheet(
            "QPushButton { font-size: 12px; font-weight: bold; "
            "background-color: lightgray; border: 2px solid black; padding: 2px; }"
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.uitlog.clicked.connect(self.uitloggen)

        self.back = QPushButton("< Terug", self)
        self.back.move(5, 155)
        self.back.setFixedSize(80, 30)
        self.back.setStyleSheet("QPushButton { font-size: 14px; font-weight: bold; background-color: lightgray; }" \
                                "QPushButton:hover { background-color: #F2F0ED; }")
        self.back.clicked.connect(self.gaterug)

        self.veraan = QPushButton("Aanpassen >", self)
        self.veraan.move(595, 155)
        self.veraan.setFixedSize(100, 30)
        self.veraan.setStyleSheet("QPushButton { font-size: 14px; font-weight: bold; background-color: lightgray; }" \
                                  "QPushButton:hover { background-color: #F2F0ED; }")
        self.veraan.clicked.connect(self.gaverdervoorraadaanpassen)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setStyleSheet("background-color: black;")
        line.setFixedHeight(2)

        vib_title = QLineEdit("", self)
        vib_title.setVisible(True)
        vib_title.setPlaceholderText("VIBs zoeken...")
        vib_title.setTextMargins(10, 0, 0, 0)
        vib_title.setFixedSize(550, 50)
        vib_title.move(75, 190)
        vib_title.setStyleSheet("background-color: white; border: 2px solid black; font-size: 20px; font-weight: 500;")
        vib_title.textChanged.connect(lambda: self.tabelmaken(verlopenweergeven, verlopen2weergeven, table, vib_title.text()))

        verlopenweergeven = QCheckBox("Voorraden van nul verbergen", self)
        verlopenweergeven.setStyleSheet("font-size: 16px; color: white;")
        verlopenweergeven.move(85, 245)
        verlopenweergeven.setChecked(False)
        verlopenweergeven.stateChanged.connect(lambda: self.tabelmaken(verlopenweergeven, verlopen2weergeven, table, vib_title.text()))

        verlopen2weergeven = QCheckBox("Voorraden van nul weergeven", self)
        verlopen2weergeven.setStyleSheet("font-size: 16px; color: white;")
        verlopen2weergeven.move(350, 245)
        verlopen2weergeven.setChecked(False)
        verlopen2weergeven.stateChanged.connect(lambda: self.tabelmaken(verlopenweergeven, verlopen2weergeven, table, vib_title.text()))

        table = QTableWidget(self)
        table.setEditTriggers(QTableWidget.NoEditTriggers)
        table.setSelectionMode(QTableWidget.NoSelection)
        table.setColumnCount(3)
        table.setFixedSize(620, 330)
        table.setVisible(True)
        table.move(50, 270)
        table.setHorizontalHeaderLabels(["Naam", "Locatie", "Voorraad"])
        table.setStyleSheet(
            "QTableWidget::item { background-color: white; border: 1px solid black; " \
            "font-size: 16px; font-style: italic; padding: 0 0 0 7px; }" \
            "QHeaderView::section { background-color: lightgray; border: 1px solid black; " \
            "font-size: 16px; }" \
            "QScrollBar { background: transparent; border-radius: 5px; }" \
            "QScrollBar::handle { background: lightgray; border-radius: 5px; }" \
            "QScrollBar::add-line:vertical," \
            "QScrollBar::sub-line:vertical { height: 0px; border: none; background: none; } " \
            "QScrollBar::add-page:vertical," \
            "QScrollBar::sub-page:vertical { background: none; } " )
        table.setColumnWidth(0, 200)
        table.setColumnWidth(1, 200)
        table.setColumnWidth(2, 200)
        table.verticalHeader().setDefaultSectionSize(50)

        self.tabelmaken(verlopenweergeven, verlopen2weergeven, table, vib_title.text())

    def gaverdervoorraadaanpassen(self):
        from .voorraad_aanpassen import voorraadaanpassen # type: ignore
        self.oorsprong = "voorraad"
        self.window2 = voorraadaanpassen(self.texmes, self.oorsprong)
        self.window2.show()
        self.close()

    def gaterug(self):
        from .home_window_admin import HomeWindowAdmin # type: ignore
        self.window2 = HomeWindowAdmin(self.texmes)
        self.window2.show()
        self.close()

    def tabelmaken(self, verlopenweergeven, verlopen2weergeven, table, vib_title_text):
        DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
        connect = sqlite3.connect(DB_PATH)
        cursor = connect.cursor()

        if verlopenweergeven.isChecked() and vib_title_text.strip() == "":
            cursor.execute("SELECT stof, locatie, voorraad FROM stoffen WHERE voorraad NOT LIKE ?", ('0%',))
            rows = cursor.fetchall()
        elif verlopen2weergeven.isChecked() and vib_title_text.strip() == "":
            cursor.execute("SELECT stof, locatie, voorraad FROM stoffen WHERE voorraad LIKE ?", ('0%',))
            rows = cursor.fetchall()
        elif vib_title_text.strip() != "":
            if len(vib_title_text) < 2:
                cursor.execute("SELECT stof, locatie, voorraad FROM stoffen WHERE stof LIKE ?", ('%' + vib_title_text + '%',))
                rows = cursor.fetchall()
            else:
                rows = []
                cursor.execute("SELECT stof FROM stoffen")
                all_rows = cursor.fetchall()
                all_names = [row[0] for row in all_rows]
                all_names_lower = [name.lower() for name in all_names]
                matches_lower = difflib.get_close_matches(
                    vib_title_text.lower(),
                    all_names_lower,
                    n=100,
                    cutoff=0.4
                )
                matches = [all_names[all_names_lower.index(m)] for m in matches_lower]
                if matches:
                    cursor.execute("SELECT stof, locatie, voorraad FROM stoffen WHERE stof IN ({})".format(','.join('?' * len(matches))), matches)
                    rows = cursor.fetchall()
        else:
            cursor.execute("SELECT stof, locatie, voorraad FROM stoffen")
            rows = cursor.fetchall()
        
        connect.close()

        table.setRowCount(0)
        table.setRowCount(len(rows))

        for r, (naam, uitgever, verloop) in enumerate(rows):
            table.setItem(r, 0, QTableWidgetItem(naam))
            table.setItem(r, 1, QTableWidgetItem(uitgever))
            table.setItem(r, 2, QTableWidgetItem(verloop))

        table.setShowGrid(False)
        table.verticalHeader().setVisible(False)
    
    def uitloggen(self):
        from login_window import LoginWindow # type: ignore
        self.window1 = LoginWindow()
        self.window1.show()
        self.close()