import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class HomeWindowAdmin(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.setWindowTitle("WelkomPagina")
        self.resize(700, 600)
        self.setMinimumSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        self.uitlog = QPushButton("Uitloggen", self)
        self.uitlog.move(600, 10)
        self.uitlog.setFixedSize(90, 30)
        self.uitlog.setStyleSheet(
            "QPushButton { font-size: 12px; font-weight: bold; "
            "background-color: lightgray; border: 2px solid black; padding: 2px; }"
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.uitlog.clicked.connect(self.uitloggen)

        self.texmes = texmes
        self.inlog = QLabel(f"Welkom Admin {self.texmes}!", self)
        self.inlog.setFixedSize(250, 20)
        self.inlog.setVisible(True)
        self.inlog.move(230, 170)
        self.inlog.setStyleSheet("font-size: 19px; color: white; font-weight: bold;")

        self.info = QLabel("U bent ter beschikking van maximale rechten.", self)
        self.info.setFixedSize(400, 20)
        self.info.setVisible(True)
        self.info.move(165, 200)
        self.info.setStyleSheet("font-size: 16px; color: white;")

        self.VIBzien = QPushButton("VIBs", self)
        self.VIBzien.move(40, 240)
        self.VIBzien.setFixedSize(200, 160)
        self.VIBzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBzien.clicked.connect(self.gaverderVIB)

        self.voorraadzien = QPushButton("Voorraden", self)
        self.voorraadzien.move(250, 240)
        self.voorraadzien.setFixedSize(200, 160)
        self.voorraadzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.voorraadzien.clicked.connect(self.gaverdervoorraad)

        self.meld = QLabel("", self)
        self.meld.move(460, 240)
        self.meld.setFixedSize(230, 160)
        self.meld.setStyleSheet("font-size: 18px; color: white; font-weight: bold;" \
        "border: 2px dotted black; background-color: white;")

        self.meld2 = QLabel("Let op!", self)
        self.meld2.move(480, 250)
        self.meld2.setFixedSize(200, 30)
        self.meld2.setStyleSheet("font-size: 18px; color: black; font-weight: bold; background-color: white;")

        self.meld3 = QLabel("", self)
        self.meld3.move(480, 275)
        self.meld3.setFixedSize(200, 60)
        self.meld3.setStyleSheet("font-size: 13px; color: black; font-weight: bold; background-color: white;")

        self.melding()

        self.upmeld = QPushButton("Melding updaten", self)
        self.upmeld.move(500, 340)
        self.upmeld.setFixedSize(150, 30)
        self.upmeld.setStyleSheet(
            "QPushButton { font-size: 12px; font-weight: bold; "
            "background-color: lightgray; border: 2px solid black; padding: 2px; }"
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.upmeld.clicked.connect(self.update)

        self.VIBverand = QPushButton("VIB's bewerken", self)
        self.VIBverand.move(130, 410)
        self.VIBverand.setFixedSize(200, 160)
        self.VIBverand.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBverand.clicked.connect(self.gaverderVIBaanpassen)

        self.voorraadverand = QPushButton("Voorraden\nbewerken", self)
        self.voorraadverand.move(340, 410)
        self.voorraadverand.setFixedSize(200, 160)
        self.voorraadverand.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.voorraadverand.clicked.connect(self.gaverdervoorraadaanpassen)

    def gaverdervoorraadaanpassen(self):
        from .voorraad_aanpassen import voorraadaanpassen # type: ignore
        self.oorsprong = "home"
        self.window3 = voorraadaanpassen(self.texmes, self.oorsprong)
        self.window3.show()
        self.close()
    
    def update(self):
        DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
        connect = sqlite3.connect(DB_PATH)
        cursor = connect.cursor()
        from datetime import datetime
        today = datetime.today().date()
        cursor.execute("SELECT min(stofverloopdatum) FROM VIBoverzicht WHERE stofverloopdatum IS NOT 'Verlopen'")
        result = cursor.fetchone()
        if result[0] is not None:
            if today > datetime.strptime(result[0], '%d-%m-%Y').date():
                cursor.execute("UPDATE VIBoverzicht SET stofverloopdatum = 'Verlopen' WHERE stofverloopdatum = ?", (result[0],))
                connect.commit()
                messagebox.showinfo("Succes", "Er is een VIB verlopen! De verloopdatum is geüpdatet.")
            else:
                messagebox.showinfo("Fout", "Alle VIBs zijn up-to-date.")

        connect.close()
    
    def melding(self):
        DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
        connect = sqlite3.connect(DB_PATH)
        cursor = connect.cursor()

        cursor.execute("SELECT min(stofverloopdatum) FROM VIBoverzicht WHERE stofverloopdatum IS NOT 'Verlopen'")
        result = cursor.fetchone()
        cursor.execute("SELECT stofnaam FROM VIBoverzicht WHERE stofverloopdatum = ?", (result[0],) if result[0] else (None,))
        stofnaam = cursor.fetchone()
        from datetime import datetime
        today = datetime.today().date()
        if result[0] <= datetime.strftime(today, '%d-%m-%Y'):
            self.meld3.setText(f"{stofnaam[0]} verloopt op \n{result[0]}\nDat is in {((datetime.strptime(result[0], '%d-%m-%Y').date() - today).days)} dagen!")
        else:
            self.meld3.setText("Fout. Update de gegevens.")

        connect.close()

    def gaverderVIBaanpassen(self):
        from .vib_aanpassen import vibaanpassen # type: ignore
        self.oorsprong = "home"
        self.window3 = vibaanpassen(self.texmes, self.oorsprong)
        self.window3.show()
        self.close()

    def gaverdervoorraad(self):
        from .voorraad_window_admin import VoorraadWindowA # type: ignore
        self.oorsprong = ""
        self.window3 = VoorraadWindowA(self.texmes)
        self.window3.show()
        self.close()
    
    def gaverderVIB(self):
        from .vib_window_admin import VIBWindowA # type: ignore
        self.oorsprong = ""
        self.window3 = VIBWindowA(self.texmes)
        self.window3.show()
        self.close()

    def uitloggen(self):
        from login_window import LoginWindow # type: ignore
        self.window1 = LoginWindow()
        self.window1.show()
        self.close()
