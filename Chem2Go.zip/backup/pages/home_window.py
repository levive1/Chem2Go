import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class HomeWindow(QWidget):
    def __init__(self, texmes):
        super().__init__()

        self.setWindowTitle("InlogPagina")
        self.resize(700, 600)
        self.setMinimumSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(700, 150)
        self.bovenform.setVisible(True)
        self.bovenform.move(0, 0)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.LogoBea = QLabel(self)
        image_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "LogoBea.png"
        )
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)
        self.LogoBea.setStyleSheet("background-color: #137827;")

        self.uitlog = QPushButton("Uitloggen", self)
        self.uitlog.move(600, 10)
        self.uitlog.setFixedSize(90, 30)
        self.uitlog.setStyleSheet(
            "QPushButton { font-size: 12px; font-weight: bold; "
            "background-color: lightgray; border: 2px solid black; padding: 2px; }"
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.uitlog.clicked.connect(self.uitloggen)

        self.texmes = texmes
        self.inlog = QLabel(f"Welkom {self.texmes}!", self)
        self.inlog.setFixedSize(250, 20)
        self.inlog.setVisible(True)
        self.inlog.move(230, 170)
        self.inlog.setStyleSheet("font-size: 20px; color: white; font-weight: bold;")

        self.info = QLabel("Als scheikundige gebruikt u een website van het \nBeatrix College, uw rechten zijn beperkt.", self)
        self.info.setFixedSize(400, 50)
        self.info.setVisible(True)
        self.info.move(160, 200)
        self.info.setStyleSheet("font-size: 16px; color: white;")

        self.VIBzien = QPushButton("VIBs \nbekijken", self)
        self.VIBzien.move(150, 280)
        self.VIBzien.setFixedSize(200, 160)
        self.VIBzien.setStyleSheet(
            "QPushButton { font-size: 14px; font-weight: bold; " \
            "background-color: white; border: 2px dotted black; padding: 5px; }" \
            "QPushButton:hover { background-color: #F2F0ED; }")
        self.VIBzien.clicked.connect(self.gaverderVIB)

        self.meld = QLabel("", self)
        self.meld.move(370, 280)
        self.meld.setFixedSize(250, 160)
        self.meld.setStyleSheet("font-size: 18px; color: white; font-weight: bold;" \
        "border: 2px dotted black; background-color: white;")

        self.meld2 = QLabel("Let op!", self)
        self.meld2.move(390, 290)
        self.meld2.setFixedSize(220, 30)
        self.meld2.setStyleSheet("font-size: 18px; color: black; font-weight: bold; background-color: white;")

        self.meld3 = QLabel("", self)
        self.meld3.move(390, 315)
        self.meld3.setFixedSize(220, 60)
        self.meld3.setStyleSheet("font-size: 13px; color: black; font-weight: bold; background-color: white;")

        self.melding()


    def melding(self):
        DB_PATH = Path(__file__).resolve().parent.parent / "database.db"
        connect = sqlite3.connect(DB_PATH)
        cursor = connect.cursor()

        cursor.execute("SELECT min(stofverloopdatum) FROM VIBoverzicht WHERE stofverloopdatum IS NOT 'Verlopen'")
        result = cursor.fetchone()
        cursor.execute("SELECT stofnaam FROM VIBoverzicht WHERE stofverloopdatum = ?", (result[0],) if result[0] else (None,))
        stofnaam = cursor.fetchone()
        from datetime import datetime
        today = datetime.today().date()
        if result[0] <= datetime.strftime(today, '%d-%m-%Y'):
            self.meld3.setText(f"{stofnaam[0]} verloopt op \n{result[0]}\nDat is in {((datetime.strptime(result[0], '%d-%m-%Y').date() - today).days)} dagen!")
        else:
            self.meld3.setText("Fout. Neem contact op \nmet een admin.")
        connect.close()


    def gaverderVIB(self):
        from .vib_window import VIBWindow # type: ignore
        self.window3 = VIBWindow(self.texmes)
        self.window3.show()
        self.close()
    
    def uitloggen(self):
        from login_window import LoginWindow # type: ignore
        self.window1 = LoginWindow()
        self.window1.show()
        self.close()
