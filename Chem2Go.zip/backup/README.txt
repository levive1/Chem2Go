Introductie tot Chem2Go

Chem2Go biedt een database aan veiligheidsinformatiebladen (VIBs) voor normale gebruikers en een database aan stoffen op het Beatrix College voor admins. 

Voor gebruik is het vereist de ZIP-file uit te pakken.
Zorg dat je de nieuwste variant van Python hebt geïnstalleerd. 
Om de applicatie in te laden runt u het programma start.py in uw gewenste IDE, wij raden Visual Studio Code aan. 
Andere programmas en codes zijn niet vereist en niet aangeraden te openen.

Werkt de applicatie niet? Open in dat geval Commandline of Powershell en installeer PyQt5 met het volgende commando:
pip install PyQt5
Werkt dat niet? Gebruik het volgende:
python -m pip install PyQt5