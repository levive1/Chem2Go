import sys
from unittest import result
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QLineEdit, QPushButton, QVBoxLayout, QMessageBox, QCheckBox, QFrame, QTableWidget, QTableWidgetItem, QHeaderView
from PyQt5.QtCore import QRegularExpression, Qt
from PyQt5.QtGui import QPixmap, QFont, QRegularExpressionValidator
import sqlite3
import os
from tkinter import messagebox
from pathlib import Path

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("InlogPagina")
        self.resize(700, 600)
        self.setMinimumSize(700, 600)
        self.setStyleSheet("background-color: #4CAF50;")

        self.bovenform = QLabel("Chem2Go", self)
        self.bovenform.setFixedSize(300, 120)
        self.bovenform.setVisible(True)
        self.bovenform.move(200, 40)
        self.bovenform.setStyleSheet("background-color: #137827; " \
        "border: 2px solid black; font-size: 50px; font-weight: bold; color: white;")
        self.bovenform.setAlignment(Qt.AlignCenter)

        self.LogoBea = QLabel(self)
        base_path = os.path.dirname(os.path.abspath(__file__))
        image_path = os.path.join(base_path, "LogoBea.png")
        pixmap = QPixmap(image_path)
        if pixmap.isNull():
            print("Afbeelding niet gevonden:", image_path)
        pixmap = pixmap.scaled(150, 120)
        self.LogoBea.setPixmap(pixmap)
        self.LogoBea.setScaledContents(True)
        self.LogoBea.move(20, 20)

        self.inlog = QLabel("Vul uw inloggegevens in:", self)
        self.inlog.setFixedSize(300, 25)
        self.inlog.setVisible(True)
        self.inlog.move(200, 190)
        self.inlog.setStyleSheet("font-size: 19px; color: white; font-weight: bold;")

        self.gebruikersnaam = QLineEdit(self)
        self.gebruikersnaam.move(210, 235)
        self.gebruikersnaam.setFixedWidth(250)
        self.gebruikersnaam.setPlaceholderText("Gebruikersnaam")
        self.gebruikersnaam.setStyleSheet("font-size: 18px; color: white;")
        allow = QRegularExpression("[a-zA-Z0-9_]*")
        allow2 = QRegularExpressionValidator(allow)
        self.gebruikersnaam.setValidator(allow2)

        self.wachtwoord = QLineEdit(self)
        self.wachtwoord.setFixedWidth(250)
        self.wachtwoord.move(210, 270)
        self.wachtwoord.setPlaceholderText("Wachtwoord")
        self.wachtwoord.setEchoMode(QLineEdit.Password)
        self.wachtwoord.setStyleSheet("font-size: 18px; color: white;")
        self.wachtwoord.setValidator(allow2)

        self.announce = QLabel("", self)
        self.announce.setFixedSize(300, 30)
        self.announce.move(200, 350)
        self.announce.setVisible(False)
        self.announce.setStyleSheet("font-size: 15px; color: white;")

        self.verstuur = QPushButton("Verstuur", self)
        self.verstuur.move(200, 315)
        self.verstuur.setFixedSize(150, 35)
        self.verstuur.setStyleSheet("QPushButton { font-size: 16px; font-weight: bold; background-color: lightgray; }"
                                    "QPushButton:hover { background-color: #F2F0ED; }")
        self.verstuur.clicked.connect(self.login)

    def login(self):
        texmes = self.gebruikersnaam.text()
        if self.gebruikersnaam.text() != "" and self.wachtwoord.text() != "":
                db_path = os.path.join(
                    os.path.dirname(os.path.abspath(__file__)),
                    "database.db"
                )
                connect = sqlite3.connect(db_path)
                cursor = connect.cursor()
                cursor.execute("SELECT user, pass FROM adminlogin WHERE user=? AND pass=?",
                               (self.gebruikersnaam.text().strip(), self.wachtwoord.text().strip()))

                if cursor.fetchone():
                    print("Admin login validated")
                    self.window2 = self.openHomeWindowAdmin(texmes)
                    self.window2.show()
                    self.close()
                    connect.close()
                    return
                else:
                    db_path = os.path.join(
                        os.path.dirname(os.path.abspath(__file__)),
                        "database.db"
                    )
                    connect = sqlite3.connect(db_path)
                    cursor = connect.cursor()
                    cursor.execute("SELECT user, pass FROM login WHERE user=? AND pass=?",
                               (self.gebruikersnaam.text().strip(), self.wachtwoord.text().strip()))

                    if cursor.fetchone():
                        print("Login validated")
                        self.window2 = self.openHomeWindow(texmes)
                        self.window2.show()
                        self.close()
                        connect.close()
                        return
                    else:
                        self.announce.setText("Onjuiste inloggegevens.")
                        self.announce.setVisible(True)
                connect.close()
        else:           
            self.announce.setText("Vul alle velden in.")
            self.announce.setVisible(True)

    def openHomeWindowAdmin(self, texmes):
        from pages.home_window_admin import HomeWindowAdmin # type: ignore
        return HomeWindowAdmin(texmes)

    def openHomeWindow(self, texmes):
        from pages.home_window import HomeWindow # type: ignore
        return HomeWindow(texmes)

